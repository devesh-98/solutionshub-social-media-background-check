import json
import boto3

def lambda_handler(event, context):

    client = boto3.client("rekognition")
    x=json.dumps(event[0])
    x=json.loads(x)
    x=x['payload']
    x=x['value']
    x=x.replace('=','":"').replace(', ','","').replace('{','{"').replace('}','"}')
    x=json.loads(x)
    print(x)
    
    # passing s3 image data path
    response = client.detect_moderation_labels(Image={"S3Object": {"Bucket": x['bucket'],"Name": x['s3_path']}}, MinConfidence=50)
    x['rekognition_output']=response['ModerationLabels']
    x['ModerationLabels']=[]
    for label in response['ModerationLabels']:
        try:
            x['ModerationLabels'].append(label['Name'])
        except:
            pass

    return x
