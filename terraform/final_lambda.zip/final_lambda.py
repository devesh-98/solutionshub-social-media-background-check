import json
import re

def lambda_handler(event, context):
    # TODO implement
    x=json.dumps(event[0])
    x=json.loads(x)
    x=x['payload']
    x=x['value']
    
    parts = re.split(r"\s*(\w+)=", x)
    x=str(dict(zip(parts[1::2], parts[2::2])))
    x=x.replace(",',","',").replace("}'}","'}").replace("'","\"")
    x=json.loads(x)
    print(x)
    
    ml_list=x['MODERATIONLABELS']
    ml_list=ml_list.replace('[','').replace(']','')
    ml_list = ml_list.split(",")
    ml_list=set(ml_list)
    print(ml_list)
    
    keywords=['gun','Violence','explosion','Weapon','Weapon Violence']
    counter=0
    x['present_moderation_keywords']=[]
    for word in ml_list:
        if (word.strip() in keywords):
            x['present_moderation_keywords'].append(word.strip())
    x['present_moderation_keywords']=list(set(x['present_moderation_keywords']))
    score=int(((len(keywords)-len(x['present_moderation_keywords']))/len(keywords))*1000)
    x['images_score']=score
    x.pop('MODERATIONLABELS')
    final_score=(score + int(x['CAPTIONS_SCORE']))/2
    if final_score <= 500:
        x['background']= 'Low'
    elif (final_score > 500 and final_score <= 750):
        x['background']= 'Moderate'
    else:
        x['background']= 'Good'
            
    print(x)
    return x
