import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    x=json.dumps(event[0])
    x=json.loads(x)
    x=x['payload']
    x=x['value']
    x=x.replace('=','":"').replace(', ','","').replace('{','{"').replace('}','"}')
    x=json.loads(x)
    print(x)
    
    comprehend=boto3.client("comprehend")
    s3=boto3.client('s3')
    file=s3.get_object(Bucket=x['bucket'],Key=x['s3_path'])
    text=str(file['Body'].read())
    
    key_phrases=comprehend.detect_key_phrases(Text=text,LanguageCode='en')
    phrases=key_phrases['KeyPhrases']
    text=''
    for i in phrases:
        text=text+' '+i['Text']
    keywords=['gun','voilence','explosion','weapon','bomb','drug','fight','blood','kill','nudity']
    counter=0
    x['present_keywords']=[]
    for word in keywords:
        if (text.find(word) == -1):
            counter=counter+1
        else:
            x['present_keywords'].append(word)
    score=int((counter/len(keywords))*1000)
    print(score)
    x['captions_score']=score
    print(x)
    return x
    
